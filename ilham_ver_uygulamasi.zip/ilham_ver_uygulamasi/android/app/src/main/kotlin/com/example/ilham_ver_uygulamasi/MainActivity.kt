package com.example.ilham_ver_uygulamasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
